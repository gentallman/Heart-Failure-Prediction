import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
import pickle

# Load the csv file
hf = pd.read_csv("heart_failure_clinical_records_dataset.csv")

# Select independent and dependent variable
x = hf.drop(columns = ["DEATH_EVENT","time"])
y = hf["DEATH_EVENT"]

# Split the dataset into train and test
x_train,x_test,y_train,y_test = train_test_split(x,y, test_size=0.2, random_state=2)


# Instantiate the model
gboost = GradientBoostingClassifier()

# Fit the model
gboost.fit(x_train, y_train)

# Make pickle file of our model
pickle.dump(gboost, open("gboost.pkl", "wb"))